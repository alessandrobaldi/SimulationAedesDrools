/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.drools.simulation;

/**
 *
 * @author alessandro
 */
public class Eggs {
   private int days = 0;

    public int getDays() {
        return days;
    }

    public void setDays(int days) {
        this.days = days;
    }
   
}
